import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from 'react-native';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { notify } from '../../utils/notify';
import AppBackground from '../../components/AppBackground/AppBackground';
import GlassSurface from '../../components/GlassSurface/GlassSurface';
import GlassButton from '../../components/GlassButton/GlassButton';
import GlassField from '../../components/GlassField/GlassField';
import Icon from '../../components/Icon/Icon';
import {
  createStyles,
  createDynamicStyles,
  animationConfig,
  validationRules,
  BACK_RADIUS,
} from './LoginScreen.styles';

const LoginScreen = () => {
  const { theme } = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const insets = useSafeAreaInsets();
  const dyn = useMemo(() => createDynamicStyles(insets), [insets]);

  const { signIn, signInAsGuest, rememberedUsername } = useAuth();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [focusedField, setFocusedField] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [guestLoading, setGuestLoading] = useState(false);
  const fadeIn = useRef(new Animated.Value(0)).current;

  /**
   * Every time this screen comes into view (first open, or back after
   * logout): clear the password and errors, and prefill the remembered
   * username if "Remember me" was ticked last time.
   */
  useEffect(() => {
    if (isFocused) {
      setUsername(rememberedUsername || '');
      setRemember(!!rememberedUsername);
      setPassword('');
      setShowPassword(false);
      setErrors({});
      setFocusedField(null);
      setSubmitting(false);
      setGuestLoading(false);
    }
  }, [isFocused, rememberedUsername]);

  useEffect(() => {
    Animated.timing(fadeIn, {
      toValue: 1,
      duration: animationConfig.fadeInDuration,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [fadeIn]);
  /**
   * BACK — return to the previous screen, or to the Splash screen when
   * there is none. Login can be reached with nothing beneath it in the
   * stack (from the guest SIGN IN button, which rebuilds the stack), and
   * goBack() then does nothing at all.
   */
  const handleBack = () => {
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.reset({ index: 0, routes: [{ name: 'Splash' }] });
    }
  };
  // ---- Validation -------------------------------------------------------

  /**
   * Checks both fields and returns every problem found.
   * Inline errors stay (they mark which field is wrong); the caller
   * also shows an alert so nothing is missed on a small screen.
   */
  const validate = () => {
    const next = {};
    const value = username.trim();
    const {
      usernamePattern,
      minUsernameLength,
      maxUsernameLength,
      minPasswordLength,
    } = validationRules;

    if (!value) {
      next.username = 'Username is required';
    } else if (value.length < minUsernameLength) {
      next.username = `Username must be at least ${minUsernameLength} characters`;
    } else if (value.length > maxUsernameLength) {
      next.username = `Username must be at most ${maxUsernameLength} characters`;
    } else if (!usernamePattern.test(value)) {
      next.username =
        'Start with a letter; use only letters, numbers, dots, underscores or hyphens';
    }

    if (!password) {
      next.password = 'Password is required';
    } else if (password.length < minPasswordLength) {
      next.password = `Password must be at least ${minPasswordLength} characters`;
    }

    setErrors(next);
    return Object.values(next).filter(Boolean);
  };

  const handleSubmit = async () => {
    const problems = validate();

    if (problems.length > 0) {
      const single = problems.length === 1;
      notify.dialog({
        type: 'warning',
        title: single ? 'Incomplete details' : 'Check your details',
        message: single
          ? problems[0]
          : problems.map(p => `\u2022 ${p}`).join('\n'),
        button: 'OK',
      });
      return;
    }

    setSubmitting(true);
    const result = await signIn({ username, password, remember });
    setSubmitting(false);

    if (result.ok) {
      navigation.reset({ index: 0, routes: [{ name: 'Dashboard' }] });
    } else {
      notify.error('Log in failed', result.message ?? 'Please try again.');
    }
  };

  const handleGuest = async () => {
    setGuestLoading(true);
    await signInAsGuest();
    setGuestLoading(false);
    navigation.reset({ index: 0, routes: [{ name: 'Dashboard' }] });
  };

  // ---- Render -----------------------------------------------------------

  return (
    <AppBackground>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={[styles.scroll, dyn.scrollPadding]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View
            style={{
              opacity: fadeIn,
              transform: [
                {
                  translateY: fadeIn.interpolate({
                    inputRange: [0, 1],
                    outputRange: [animationConfig.fadeInOffset, 0],
                  }),
                },
              ],
            }}
          >
            <Pressable
              onPress={handleBack}
              hitSlop={12}
              accessibilityRole="button"
              accessibilityLabel="Back"
              style={({ pressed }) => [
                styles.backWrap,
                pressed && styles.backPressed,
              ]}
            >
              <GlassSurface
                strong
                radius={BACK_RADIUS}
                contentStyle={styles.backInner}
              >
                <Icon
                  name="chevronLeft"
                  size={26}
                  color={theme.icon.heading}
                  weight={3}
                />
                <Text style={styles.backText}>Back</Text>
              </GlassSurface>
            </Pressable>

            <View style={styles.header}>
              <Text style={styles.heading}>Log in</Text>
              <Text style={styles.subheading}>
                Access the Ombudsman Punjab Management Information System
              </Text>
            </View>

            <GlassSurface style={styles.card}>
              {/* ---------- USERNAME ---------- */}
              <Text style={styles.label}>USERNAME</Text>
              <GlassField
                focused={focusedField === 'username'}
                errored={!!errors.username}
                value={username}
                onChangeText={text => {
                  setUsername(text);
                  if (errors.username) {
                    setErrors(prev => ({ ...prev, username: undefined }));
                  }
                }}
                onFocus={() => setFocusedField('username')}
                onBlur={() => setFocusedField(null)}
                placeholder="Enter username"
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="username"
                textContentType="username"
                maxLength={validationRules.maxUsernameLength}
                returnKeyType="next"
              />
              {!!errors.username && (
                <Text style={styles.error}>{errors.username}</Text>
              )}

              {/* ---------- PASSWORD ---------- */}
              <Text style={[styles.label, styles.labelSpaced]}>PASSWORD</Text>
              <GlassField
                focused={focusedField === 'password'}
                errored={!!errors.password}
                value={password}
                onChangeText={text => {
                  setPassword(text);
                  if (errors.password) {
                    setErrors(prev => ({ ...prev, password: undefined }));
                  }
                }}
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
                placeholder="Enter your password"
                secureTextEntry={!showPassword}
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="password"
                textContentType="password"
                returnKeyType="done"
                onSubmitEditing={handleSubmit}
                action={
                  <Pressable
                    onPress={() => setShowPassword(prev => !prev)}
                    hitSlop={12}
                    style={styles.toggle}
                    accessibilityRole="button"
                    accessibilityLabel={
                      showPassword ? 'Hide password' : 'Show password'
                    }
                  >
                    <Icon
                      name={showPassword ? 'eyeOff' : 'eye'}
                      size={22}
                      color={theme.icon.body}
                      weight={2}
                    />
                  </Pressable>
                }
              />
              {!!errors.password && (
                <Text style={styles.error}>{errors.password}</Text>
              )}

              {/* ---------- OPTIONS ---------- */}
              <View style={styles.optionsRow}>
                <Pressable
                  onPress={() => setRemember(prev => !prev)}
                  hitSlop={8}
                  style={styles.rememberRow}
                >
                  <View
                    style={[styles.checkbox, remember && styles.checkboxOn]}
                  >
                    {remember && (
                      <Icon
                        name="check"
                        size={14}
                        color={theme.icon.onAccent}
                        weight={2}
                      />
                    )}
                  </View>
                  <Text style={styles.rememberText}>Remember me</Text>
                </Pressable>
              </View>

              <GlassButton
                label="LOG IN"
                onPress={handleSubmit}
                loading={submitting}
                style={styles.submit}
              />

              <View style={styles.dividerRow}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>OR</Text>
                <View style={styles.dividerLine} />
              </View>

              <GlassButton
                label="CONTINUE AS GUEST"
                variant="glass"
                loading={guestLoading}
                onPress={handleGuest}
                icon={<Icon name="user" size={17} color="#FFFFFF" />}
              />
            </GlassSurface>

            <Text style={styles.footer}>
              Office of the Ombudsman, Punjab {'\u00B7'} OPMIS {'\u00B7'} v1.10
            </Text>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </AppBackground>
  );
};

export default LoginScreen;
